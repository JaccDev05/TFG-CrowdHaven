package com.CrowdHaven.Backend.models;

import com.CrowdHaven.Backend.Enums.rew_type;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "rewardTypes")
@Getter
@Setter
public class RewardType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private rew_type type;

}