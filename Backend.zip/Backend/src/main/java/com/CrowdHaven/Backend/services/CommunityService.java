package com.CrowdHaven.Backend.services;

import com.CrowdHaven.Backend.models.Community;
import com.CrowdHaven.Backend.models.User;
import com.CrowdHaven.Backend.repositories.CommunityRepository;
import com.CrowdHaven.Backend.repositories.RoleRepository;
import com.CrowdHaven.Backend.repositories.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CommunityService {

    private final CommunityRepository communityRepository;
    private  final UserRepository userRepository;
    private final RoleRepository roleRepository;

    public List<Community> getAllCommunities() {
        return communityRepository.findAll();
    }

    public List<Community> getAllCommunitiesbyUser(Long id) {
        return communityRepository.findByUserID(id);
    }

    public List<User> getAllUsersByCommunity(String name) {
        return userRepository.findByCommunity(name);
    }

    public Community updateProduct(Long id, Community comDetails) {
        Community community = communityRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("producto no encontrado"));

        community.set(productDetails.getName());
        product.setDescription(productDetails.getDescription());
        product.setPrice(productDetails.getPrice());

        return productRepository.save(product);
    }

    public Optional<Product> getProdById(long id) {
        return this.productRepository.findById(id);
    }

    public Product createProduct(ProductRequest productFromFront) {

        if(!this.userRepository.existsByUsername(productFromFront.getSeller())){
            throw new IllegalArgumentException("No existe el seller");
        }

        else {


            Product product = new Product();
            product.setName(productFromFront.getName());
            product.setDescription(productFromFront.getDescription());
            product.setImage(productFromFront.getImage());
            product.setPrice(productFromFront.getPrice());
            product.setTax(productFromFront.getTax());
            product.setCurrency(productFromFront.getCurrency());
            product.setSeller(this.userRepository.findByUsername(productFromFront.getSeller()).get());

            this.productRepository.save(product);
            return product;
        }
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }
}
}
