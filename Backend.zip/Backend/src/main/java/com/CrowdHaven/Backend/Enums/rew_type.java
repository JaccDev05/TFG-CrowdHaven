package com.CrowdHaven.Backend.Enums;

public enum rew_type {
    INSIGNIA
}
